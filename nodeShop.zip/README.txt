para rodar o servidor nã utilize o comando node (insira aqui o nome do arquivo)

use o comando do nodemon ./(nome do arquivo com extenção);




//caso a classe nem sempre exista dentro da pagina usar a função abaixo
    /*const exemplo = await page.evaluate(() => {
        const elemento = document.querySelector('.classe');
        if (!elemento) return null;
        return elemento.innerText;
    })*/


    //const price = await page.$eval('Seletor' , element => element.innerText);


    //let exe = (exemplo ? obj.exemplo = exemplo : '');


    // list.push(obj);
